package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.DTO.BoardDTO;
import com.DTO.For_dicDTO;

public class For_dicDAO {

	   private Connection conn = null;
	   private PreparedStatement pst = null;
	   private ResultSet rs = null;
	   int cnt = 0;

	   private void getConn() {
	      try {
	          Class.forName("oracle.jdbc.driver.OracleDriver");
	          
	            String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
	            String user_id = "hr";
	            String user_pw = "hr";
	            conn = DriverManager.getConnection(url, user_id, user_pw);
	            if (conn != null) {
	               System.out.println("���� ����");
	            } else {
	               System.out.println("���� ����");
	            }
	         } catch (Exception e) {
	            e.printStackTrace();
	         }
	   }

	   private void close() {
	      try {
	         if (pst != null) {
	            pst.close();
	         }
	         if (conn != null) {
	            conn.close();
	         }
	      } catch (Exception e2) {
	         e2.printStackTrace();
	      }
	   }

	   public For_dicDTO SelectVideo (For_dicDTO dto) {
		      getConn();//connection
		      
		      For_dicDTO info= null;
		      
		      try {
		         String sql = "select * from for_dic where word = ?";
		         
		         pst = conn.prepareStatement(sql);
		         pst.setString(1, dto.getWord());
		         
		         rs = pst.executeQuery();
		         
		         while(rs.next()) { 
		            String word = rs.getString(1);
		            String link_us = rs.getString(2);
		            String link_uk = rs.getString(3);
		            String link_spain = rs.getString(4);
		            String link_france = rs.getString(5);
		            String link_germany = rs.getString(6);
		            
		            info = new For_dicDTO(word, link_us, link_uk, link_spain, link_france, link_germany);
		         }
		         
		      } catch (SQLException e) {
		         e.printStackTrace();
		      } finally {
		         close();
		      }
		      return info;
		   }
}
