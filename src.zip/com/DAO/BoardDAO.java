package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.DTO.BoardDTO;

public class BoardDAO {

	   private Connection conn = null;
	   private PreparedStatement pst = null;
	   private ResultSet rs = null;
	   int cnt = 0;

	   private void getConn() {
	      try {
	          Class.forName("oracle.jdbc.driver.OracleDriver");
	          
	            String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
	            String user_id = "hr";
	            String user_pw = "hr";
	            conn = DriverManager.getConnection(url, user_id, user_pw);
	            if (conn != null) {
	               System.out.println("success");
	            } else {
	               System.out.println("fail");
	            }
	         } catch (Exception e) {
	            e.printStackTrace();
	         }
	   }

	   private void close() {
	      try {
	         if (pst != null) {
	            pst.close();
	         }
	         if (conn != null) {
	            conn.close();
	         }
	      } catch (Exception e2) {
	         e2.printStackTrace();
	      }
	   }

	   public int SendMessage (BoardDTO dto) {
		   
		   getConn();
	       try {
	          getConn();
	          String sql = "insert into board(board_num, name, email, message, day) values(board_num.nextval, ?, ?, ?, sysdate)";
	            
	             pst = conn.prepareStatement(sql);
	             pst.setString(1, dto.getName());
	             pst.setString(2, dto.getEmail());
	             pst.setString(3, dto.getMessage());

	          cnt = pst.executeUpdate();
	         
	       } catch (Exception e) {
	          e.printStackTrace();
	       } finally {
	          close();
	       }

	       return cnt;
	   }
}
