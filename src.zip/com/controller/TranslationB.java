package com.controller;

import java.io.PrintWriter;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.BoardDAO;
import com.DAO.TranslationBDAO;
import com.DAO.For_dicDAO;
import com.DTO.BoardDTO;
import com.DTO.TranslationBDTO;
import com.DTO.For_dicDTO;
import com.front.Command;

@WebServlet("/TranslationB")
public class TranslationB implements Command {
	

	public String execute(HttpServletRequest request, HttpServletResponse response) {

		String message = request.getParameter("message");
		System.out.println("controller : " + message);
		
		TranslationBDAO dao = new TranslationBDAO();
		TranslationBDTO info2 = dao.SelectVideo2(message);
		
		String page2 = info2.getLink_b();
		
		System.out.println("수어영상 db 연결 성공");
		System.out.println("세션 값, 넘어온 페이지"+page2);
		
		//HttpSession session = request.getSession();
		//session.removeAttribute("info2");
		/*
		 * if(session != null) { session.removeAttribute("info2"); }
		 */
		//session.setAttribute("info2", info2);
		
		System.out.println("영상 파일 경로 확인//////////////// : "+ info2.getLink_b());
		System.out.println("영상 넘어간다");
		
		return info2.getLink_b(); // 영상 파일 경로 문자열을 Main.jsp로 바로 넘겨주기
	}
	
}
