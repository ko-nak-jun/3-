package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.For_dicDAO;
import com.DTO.For_dicDTO;
import com.front.Command;

public class For_dic implements Command{

	public String execute(HttpServletRequest request, HttpServletResponse response) {
		
		String word = request.getParameter("word");
		String link_us = request.getParameter("link_us");
		String link_uk = request.getParameter("link_uk");
		String link_spain = request.getParameter("link_spain");
		String link_france = request.getParameter("link_spain");
		String link_germany = request.getParameter("link_germany");
		
		
		For_dicDTO dto = new For_dicDTO(word, link_us, link_uk, link_spain, link_france, link_germany);
		For_dicDAO dao = new For_dicDAO();
		For_dicDTO info = dao.SelectVideo(dto);
		
		String page = null;
		
		if (info != null) {
			System.out.println("video db 연결 성공");
			
			if (info.getWord().equals(word)) {
				HttpSession session = request.getSession();
				session.setAttribute("info", info);
				page = "For_dic.jsp";
			} else {
				HttpSession session = request.getSession();
				session.setAttribute("info", info);
				page = "Main.jsp";
			};
			
		} else {
			System.out.println("video db 연결 실패");
		};
		
		
		return page;

	}
}
