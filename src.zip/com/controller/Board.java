package com.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DAO.BoardDAO;
import com.DTO.BoardDTO;
import com.front.Command;

public class Board implements Command{

	public String execute(HttpServletRequest request, HttpServletResponse response) {
		
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String message = request.getParameter("message");
		
		BoardDTO dto = new BoardDTO(name, email, message);
		BoardDAO dao = new BoardDAO();
		int cnt = dao.SendMessage(dto);	
		
		if (cnt > 0) {
			System.out.println("메시지 전송 성공");
		}else {
			System.out.println("메시지 전송 실패");
		}
		return "Main.jsp";
	}

	
}
