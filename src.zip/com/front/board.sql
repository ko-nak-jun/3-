
DROP TABLE board CASCADE CONSTRAINTS PURGE;


/////////////////////////////////////////////////////


CREATE TABLE board(
board_num number NOT NULL,
name VARCHAR2(30) NOT NULL,
email VARCHAR2(100) NOT NULL,
message VARCHAR2(2000) NOT NULL,
day date NOT NULL);

create sequence board_num Start with 1 increment by 1;

DROP SEQUENCE board_num;

INSERT INTO board(board_num, name, email, message, day) VALUES(
   board_num.nextval,
   '상혁',
   'sh@gmail.com',
   '안녕하세요! 서비스 좋네요.',
   sysdate);
   
delete from board;

SELECT * FROM board;