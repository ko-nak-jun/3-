DROP TABLE translation_b CASCADE CONSTRAINTS PURGE;


/////////////////////////////////////////////////////


CREATE TABLE translation_b(
korean VARCHAR2(2000) NOT NULL,
link_b VARCHAR2(1000) NOT NULL
);

INSERT INTO translation_b(korean, link_b) VALUES(
   '번호표 뽑으세요',
   'images/no1.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
   '통역이 필요해요',
   'images/no2.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
	'복지관 다녀오세요',
    'images/no3.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
	'복지카드가 필요해요',
    'images/no4.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
	'빠른등기 있습니다',
    'images/no5.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
	'복사본이 필요해요',
    'images/no6.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
	'이름과 나이를 기입하세요',
    'images/no7.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
	'공인인증서가 필요합니다',
    'images/no8.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
	'마스크 때문에 오셨나요?',
    'images/no9.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
	'신분증이 필요합니다',
    'images/no10.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
	'다시 설명해드릴게요',
    'images/no11.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
	'고맙습니다',
    'images/no12.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
	'여기서 기다리세요',
    'images/no13.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
	'만원입니다',
    'images/no14.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
	'오른쪽에 있습니다',
    'images/no15.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
	'5분 정도 여기서 기다리세요',
    'images/no16.mp4'
);

INSERT INTO translation_b(korean, link_b) VALUES(
	'왼쪽 횡단보도 건너입니다',
    'images/no17.mp4'
);

SELECT * FROM translation_b;

commit
