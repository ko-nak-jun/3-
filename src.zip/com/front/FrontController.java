package com.front;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DTO.TranslationBDTO;
import com.controller.Board;
import com.controller.TranslationB;
import com.controller.For_dic;
import com.sun.xml.internal.ws.client.SenderException;

@WebServlet("*.do")
public class FrontController extends HttpServlet {

	private HashMap<String, Command> map;

	@Override
	public void init() throws ServletException {
		map = new HashMap<String, Command>(); //
		map.put("Board.do", new Board());
		map.put("For_dic.do", new For_dic());
		map.put("TranslationB.do", new TranslationB());
	}

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("성공");

		String requestURI = request.getRequestURI();
		String contextPath = request.getContextPath();

		String resultURL = requestURI.substring(contextPath.length() + 10);
		System.out.println(resultURL);

		request.setCharacterEncoding("UTF-8");

		System.out.println(resultURL);

		Command command = map.get(resultURL);

		String moveURL = command.execute(request, response);
		System.out.println("꺄루리리" + moveURL);
		
		if (resultURL.equals("TranslationB.do")) { // TranslationB.do로 넘어가면 printwriter로 영상 경로 문자열을 바로 넘겨주겠다.
			PrintWriter out = response.getWriter();
			out.print(moveURL);
		} else {
			response.sendRedirect(moveURL);
		}
	}

}
