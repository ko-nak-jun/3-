
DROP TABLE for_dic CASCADE CONSTRAINTS PURGE;


/////////////////////////////////////////////////////


CREATE TABLE for_dic(
word VARCHAR2(100),
link_us VARCHAR2(100),
link_uk VARCHAR2(100),
link_spain VARCHAR2(100),
link_france VARCHAR2(100),
link_germany VARCHAR2(100),
CONSTRAINT word_pk PRIMARY KEY (word)
);


INSERT INTO for_dic(word, link_us, link_uk, link_spain, link_france, link_germany) VALUES(
   '안녕',
   'images/hi_01us.mp4',
   'images/hi_02uk.mp4',
   'images/hi_03spain.mp4',
   'images/hi_04france.mp4',
   'images/hi_05germany.mp4'
);

INSERT INTO for_dic(word, link_us, link_uk, link_spain, link_france, link_germany) VALUES(
   '아니오',
   'images/no_01us.mp4',
   'images/no_02uk.mp4',
   'images/no_03spain.mp4',
   'images/no_04france.mp4',
   'images/no_05germany.mp4'
);

INSERT INTO for_dic(word, link_us, link_uk, link_spain, link_france, link_germany) VALUES(
   '네',
   'images/yes_01us.mp4',
   'images/yes_02uk.mp4',
   'images/yes_03spain.mp4',
   'images/yes_04france.mp4',
   'images/yes_05germany.mp4'
);

INSERT INTO for_dic(word, link_us, link_uk, link_spain, link_france, link_germany) VALUES(
   '영수증',
   'images/receipt_01us.mp4',
   'images/receipt_02uk.mp4',
   'images/receipt_03spain.mp4',
   'images/receipt_04france.mp4',
   'images/receipt_05germany.mp4'
);

INSERT INTO for_dic(word, link_us, link_uk, link_spain, link_france, link_germany) VALUES(
   '서명',
   'images/sign_01us.mp4',
   'images/sign_02uk.mp4',
   'images/sign_03spain.mp4',
   'images/sign_04france.mp4',
   'images/sign_05germany.mp4'
);

INSERT INTO for_dic(word, link_us, link_uk, link_spain, link_france, link_germany) VALUES(
   '서류',
   'images/doc_01us.mp4',
   'images/doc_02uk.mp4',
   'images/doc_03spain.mp4',
   'images/doc_04france.mp4',
   'images/doc_05germany.mp4'
);

INSERT INTO for_dic(word, link_us, link_uk, link_spain, link_france, link_germany) VALUES(
   '필요하다',
   'images/need_01us.mp4',
   'images/need_02uk.mp4',
   'images/need_03spain.mp4',
   'images/need_04france.mp4',
   'images/need_05germany.mp4'
);

INSERT INTO for_dic(word, link_us, link_uk, link_spain, link_france, link_germany) VALUES(
   '벌금',
   'images/fine_01us.mp4',
   'images/fine_02uk.mp4',
   'images/fine_03spain.mp4',
   'images/fine_04france.mp4',
   'images/fine_05germany.mp4'
);

INSERT INTO for_dic(word, link_us, link_uk, link_spain, link_france, link_germany) VALUES(
   '중요',
   'images/important_01us.mp4',
   'images/important_02uk.mp4',
   'images/important_03spain.mp4',
   'images/important_04france.mp4',
   'images/important_05germany.mp4'
);
   
   
SELECT * FROM for_dic;


commit