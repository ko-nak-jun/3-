package com.DTO;

public class BoardDTO {
	
	private int board_num;
	private String name;
	private String email;
	private String message;
	private String day;
	
	public BoardDTO(int board_num, String name, String email, String message, String day) {
		this.board_num = board_num;
		this.name = name;
		this.email = email;
		this.message = message;
		this.day = day;
	}
	public BoardDTO(String name, String email, String message) {
		this.name = name;
		this.email = email;
		this.message = message;
	}
	public int getBoard_num() {
		return board_num;
	}
	public void setBoard_num(int board_num) {
		this.board_num = board_num;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	
	
	
	

}
