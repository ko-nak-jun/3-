package com.DTO;

public class For_dicDTO {
	
	private String word;
	private String link_us;
	private String link_uk;
	private String link_spain;
	private String link_france;
	private String link_germany;
	
	public For_dicDTO(String word, String link_us, String link_uk, String link_spain, String link_france,
			String link_germany) {
		this.word = word;
		this.link_us = link_us;
		this.link_uk = link_uk;
		this.link_spain = link_spain;
		this.link_france = link_france;
		this.link_germany = link_germany;
	}
	public String getWord() {
		return word;
	}
	public void setWord(String word) {
		this.word = word;
	}
	public String getLink_us() {
		return link_us;
	}
	public void setLink_us(String link_us) {
		this.link_us = link_us;
	}
	public String getLink_uk() {
		return link_uk;
	}
	public void setLink_uk(String link_uk) {
		this.link_uk = link_uk;
	}
	public String getLink_spain() {
		return link_spain;
	}
	public void setLink_spain(String link_spain) {
		this.link_spain = link_spain;
	}
	public String getLink_france() {
		return link_france;
	}
	public void setLink_france(String link_france) {
		this.link_france = link_france;
	}
	public String getLink_germany() {
		return link_germany;
	}
	public void setLink_germany(String link_germany) {
		this.link_germany = link_germany;
	}
	
	
	
	
	

}
