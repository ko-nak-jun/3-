package com.DTO;

public class TranslationBDTO {
	
	private String korean;
	private String link_b;
	
	public TranslationBDTO(String korean, String link_b) {
		this.korean = korean;
		this.link_b = link_b;
	}

	public String getKorean() {
		return korean;
	}

	public void setKorean(String korean) {
		this.korean = korean;
	}

	public String getLink_b() {
		return link_b;
	}

	public void setLink_b(String link_b) {
		this.link_b = link_b;
	}
	

}
