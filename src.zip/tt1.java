

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAO.TranslationBDAO;
import com.DTO.TranslationBDTO;
import com.front.Command;

/**
 * Servlet implementation class tt1
 */
@WebServlet("/tt1")
public abstract class tt1 implements Command {
	
	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		
		String message = request.getParameter("message");
		System.out.println("controller : " + message);
		
		TranslationBDAO dao = new TranslationBDAO();
		TranslationBDTO info2 = dao.SelectVideo2(message);
		
		String page2 = info2.getLink_b();
		
		System.out.println("수어영상 db 연결 성공");
		HttpSession session = request.getSession();				
		session.setAttribute("info2", info2);
		System.out.println("넘어간다");
		return page2;

	}
}
